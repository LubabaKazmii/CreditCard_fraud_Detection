# user_panel.py
import streamlit as st
import random
from fraud_model import predict_fraud_status
from database import insert_transaction



def user_panel():
    # User panel code
    st.title("User Panel")
    st.write("Welcome to the User Panel!")
with st.form("transaction_form"):
    tx_amount = st.number_input("Transaction Amount", min_value=1.0, step=0.01)
    customer_id = st.number_input("Customer ID", min_value=1000, max_value=99999, step=1)
    terminal_id = st.number_input("Terminal ID", min_value=1000, max_value=99999, step=1)
    tx_time_seconds = st.number_input("Transaction Time (seconds)", min_value=0, max_value=86400, step=1)
    tx_time_days = st.number_input("Transaction Day", min_value=1, max_value=30, step=1)
    location = st.selectbox("Location", ['New York', 'Los Angeles', 'Chicago', 'San Francisco', 'Miami'])

    submit_button = st.form_submit_button("Submit Transaction")

    if submit_button:
        fraud_status = predict_fraud_status(tx_amount, tx_time_seconds, tx_time_days, customer_id, terminal_id)
        transaction_id = f"TX{random.randint(10000, 999999)}"
        tx_datetime = f"4/{random.randint(1, 30)}/2018 {random.randint(0, 23)}:{random.randint(0, 59)}"

        insert_transaction((
            transaction_id, tx_datetime, customer_id, terminal_id, 
            tx_amount, tx_time_seconds, tx_time_days, location, 
            fraud_status, 'Proceed'
        ))

        st.success(f"Transaction {transaction_id} submitted successfully!")
        st.write(f"**Fraud Status:** {fraud_status}")
